package queueNorris;

/**
 * @author Nicholas Norris 
 *This is the Queue class
 *enqueue method places an item in the array
 *the dequeue method, places an item in the queue array
 *isEmpty method checks to see if the queue array is empty or not
 *size method displays the amount of items in the array
 *print method prints out the entire array
 *peek method displays the first item of the queue
 *
 */
public class Queue {
	
	private int maxSize; 
	private String[] queueArray;
	private int front;
	private int back;
	private int nItems;
	
	public Queue() {
		this.maxSize = 5;
		queueArray = new String[maxSize];
		this.front = 0;
		this.back = -1;
		this.nItems = 0;
	}
	public void enqueue(String item) {
		if(back == maxSize-1) //handles wrap around 
			{ 
			back = -1; 
			}
		queueArray[++back] = item;
		nItems++; //increments the number of items in the queue
	}
	public String dequeue() {
		String rando = queueArray[front++];
		if(front == maxSize) { //handles wrap around
			front = 0;
		}
		nItems--; //decrements the number of items
		return rando; 
		
	}
	public boolean isEmpty() {
		return (nItems == 0);
	}
	public int size () {
		return nItems; 
	}
	public void print() {
		for(String elem : queueArray) {
			System.out.println(elem);
		}
	}
	public String peek() {
		return queueArray[front];
	}
	
}
