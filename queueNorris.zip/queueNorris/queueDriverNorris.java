package queueNorris;

/**
 * @author Nicholas Norris
 * This is the tester for the Queue class
 * 
 *
 */
public class queueDriverNorris extends Queue{
	
	public static void main(String [] args) {
		
		//creates an array of the Queue type
		Queue test = new Queue();
		
		//places animals in the queue 
		test.enqueue("doge");
		test.enqueue("mini Apex Predator");
		test.enqueue("mini floof");
		test.enqueue("round pink mammal");
		test.enqueue("winged chicken");
		
		//prints the queue and the size of the queue
		test.print();
		System.out.println(test.size());
		
		//this will test the wrap around of the queue
		test.enqueue("mini doge");
		
		test.print();
		System.out.println(test.size());
		
		//removes and prints items from the queue
		System.out.println(test.dequeue());
		System.out.println(test.dequeue());
		
		System.out.println(test.size());
		
		System.out.println(test.dequeue());
		
		//looks at the front of the queue array
		System.out.println(test.peek());
		
		System.out.println(test.dequeue());
		System.out.println(test.dequeue());
		System.out.println(test.dequeue());
		
		System.out.println(test.size());
		
		//is the queue empty of items?
		System.out.println(test.isEmpty());
		
		System.out.println("This marks the beginning of the second test");
		//creates a second array of the queue type
		Queue secondTest = new Queue();
		
		secondTest.enqueue("Pippa");
		secondTest.enqueue("Mija");
		secondTest.enqueue("Ray");
		secondTest.enqueue("Josh");
		secondTest.enqueue("Becca");
		
		secondTest.print();
		System.out.println(secondTest.size());
		
		System.out.println(secondTest.dequeue());
		secondTest.size();
		secondTest.enqueue("Chelsea");
		
		secondTest.print();
		System.out.println(secondTest.size());
	}
}
